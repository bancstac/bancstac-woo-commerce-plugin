<?php

class ReportTransactionType {
    
    public static $CREDIT_CARD = "CREDIT_CARD";
    public static $DIRECT_ENTRY = "DIRECT_ENTRY";
    public static $BOTH ="BOTH";
}
